package de.miguel.frozzenlist.frozzenbetaa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

import com.orhanobut.hawk.Hawk;

import java.util.ArrayList;
import java.util.HashMap;

/*
    ========================================================================
    @author Miguel Gutierrez, project FrozzenList
    @version 1.0Beta
    @param to manage freezer: addFreezer(), removeFreezer(), getFrezzer()
           To add Freezer we need to have number of Trays and a frezzer name
           We need to set a error information in editText field for Exceptions
           (parsing)we include to join a frezzermember on the same Activity
     @link Hawk freezerList to save freezer for Account
    ========================================================================

 */

public class FreezerManager extends AppCompatActivity {

    EditText inputName;
    EditText inputNumberTrays;
    Button addFreezer;
    Spinner freezerList;
    User user;

    public FreezerManager() {


    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_freezer_manager);
        user = new UserManager(this).userList.get(getIntent().getIntExtra("position",0));
        inputName = (EditText) findViewById(R.id.editTextName);
        inputNumberTrays = (EditText) findViewById(R.id.editTextNumberTray);
        addFreezer = (Button) findViewById(R.id.btnAdd);
        //freezerList=(Spinner)findViewById(R.id.spinner);

        addFreezer.setOnClickListener(view->onButtonClick());
        ArrayAdapter<Freezer>adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,user.freezers);
        freezerList.setAdapter(adapter);
        freezerList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

           int spinnerposition= freezerList.getSelectedItemPosition();

       }
        });


    }

    private void onButtonClick() {
        String name= inputName.getText().toString();
        try{
            int traySize= Integer.parseInt(inputNumberTrays.getText().toString());
            Freezer freezer = new Freezer(name,traySize);
            user.freezers.add(freezer);
        }catch (NumberFormatException exception){
            inputNumberTrays.setError("Du darfst nur eine ganze Zahl für die" +
                    " Anzahl der Fächer verwenden");
        }


    }


}